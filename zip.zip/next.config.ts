import type { NextConfig } from "next";

// Force restart
const nextConfig: NextConfig = {
};

export default nextConfig;
